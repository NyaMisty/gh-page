#!/bin/bash
set -e

applink > /dev/null

BUNDLE=$1

APPDIR="$(realpath /var/mobile/Documents/App-link/App/$BUNDLE/*.app)"
APPCONTAINER="$(realpath /var/mobile/Documents/App-link/Data/$BUNDLE)"

BUNDLENAME="$(basename $APPDIR)"
EXECUTABLE="${BUNDLENAME%.*}"
ORIEXEC="$APPDIR/$EXECUTABLE"
CONTAINER_ID="$(basename $APPCONTAINER)"
echo "Got bundle id $BUNDLE in $APPDIR, executable $EXECUTABLE, container $CONTAINER_ID"

NEWEXEC="/Applications/DemoApp.app/kernbypass/$EXECUTABLE"
flexdecrypt $ORIEXEC
cp "/tmp/$EXECUTABLE" "$NEWEXEC"
chmod +x "$NEWEXEC"

ENT="/Applications/DemoApp.app/kernbypass/$EXECUTABLE.plist"
ldid -e "$ORIEXEC" > $ENT

plutil -key "com.apple.private.security.no-container" -true $ENT
plutil -key "get-task-allow" -true $ENT
plutil -key "proc_info-allow" -true $ENT
plutil -key "task_for_pid-allow" -true $ENT
plutil -key "run-unsigned-code" -true $ENT
plutil -key "platform-application" -true $ENT
plutil -key "com.apple.security.iokit-user-client-class" -array $ENT
plutil -key "com.apple.security.iokit-user-client-class" -arrayadd -string "iokit-open" $ENT
plutil -key "com.apple.security.iokit-user-client-class" -arrayadd -string "AGXDeviceUserClient" $ENT
plutil -key "com.apple.security.iokit-user-client-class" -arrayadd -string "IOSurfaceRootUserClient" $ENT

plutil -key "com.apple.security.temporary-exception.files.absolute-path.read-write" -array $ENT
plutil -key "com.apple.security.temporary-exception.files.absolute-path.read-write" -arrayadd -string "/private/var/MobileSoftwareUpdate/mnt1" $ENT
plutil -key "proc_info-allow" -true $ENT
plutil -key "proc_info-allow" -true $ENT

/var/mobile/kernbypass_asset/ldid_bigvmsize "-S$ENT" "$NEWEXEC"

FAKE_CONTAINER_DIR=/var/MobileSoftwareUpdate/mnt1/private/var/mobile/Containers/Data/Application


ln -sf $NEWEXEC "${APPDIR}/${EXECUTABLE}_kernbypass"
if [ ! -d "$FAKE_CONTAINER_DIR/$BUNDLE" ]; then
    cp -ra /var/mobile/kernbypass_asset/container_template/. $FAKE_CONTAINER_DIR/$BUNDLE
fi

(cd $FAKE_CONTAINER_DIR; ln -sf $BUNDLE $CONTAINER_ID)
