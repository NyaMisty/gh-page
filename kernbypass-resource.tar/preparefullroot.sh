umount -f /private/var/MobileSoftwareUpdate/mnt1/private/var/

detach disk2

preparerootfs

DISK=$(attach2 /var/mobile/kernbypass_asset/kernbypass.dmg)

export CONTAINER_TEMPLATE=/var/mobile/kernbypass_asset/container_template
export APPC=/private/var/MobileSoftwareUpdate/mnt1/private/var/mobile/Containers/Data/Application/
#chown mobile:mobile $APPC
#chmod 777 $APPC
mount -t hfs /dev/${DISK}s2 $APPC

exit 0

find /private/var/mobile/Containers/Data/Application -maxdepth 1 -type d -exec sh -c 'DIR=/private/var/MobileSoftwareUpdate/mnt1/$1; echo "Processing $1"; if [ -d $DIR ]; then exit; fi; mkdir $DIR && chown mobile:mobile $DIR && chmod -R 777 $DIR && cp -ra $CONTAINER_TEMPLATE/. $DIR' test {} \;
#sudo chown mobile:mobile /private/var/MobileSoftwareUpdate/mnt1/private/var/mobile/Containers/Data/Application/*
#sudo chmod 777 /private/var/MobileSoftwareUpdate/mnt1/private/var/mobile/Containers/Data/Application/*
